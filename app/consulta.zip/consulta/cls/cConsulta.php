<?php class cConsulta extends mConsulta {



} ?>