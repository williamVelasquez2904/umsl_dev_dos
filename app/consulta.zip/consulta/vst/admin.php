<div id="datoconsulta"></div>
<script>
	load('vst-consulta-buscarConsultaPac','','#datoconsulta');
</script>